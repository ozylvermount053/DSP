package com.dspeq.eq;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
    WebView web;

    class Br {
        @JavascriptInterface
        public String load() {
            return getSharedPreferences("eq", 0).getString("s", "");
        }

        @JavascriptInterface
        public void apply(String s) {
            getSharedPreferences("eq", 0).edit().putString("s", s).apply();
            EqService.load(s);
            EqService.update();
        }

        @JavascriptInterface
        public String status() {
            return EqService.status();
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        web = new WebView(this);
        setContentView(web);
        web.setOnApplyWindowInsetsListener((v, i) -> {
            Insets s = i.getInsets(WindowInsets.Type.systemBars());
            v.setPadding(s.left, s.top, s.right, s.bottom);
            return WindowInsets.CONSUMED;
        });
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        web.addJavascriptInterface(new Br(), "Android");
        web.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
        startForegroundService(new Intent(this, EqService.class));
    }

    @Override
    protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }
}
