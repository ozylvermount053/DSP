package com.dspeq.eq;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.media.audiofx.AudioEffect;
import android.media.audiofx.DynamicsProcessing;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class EqService extends Service {
    static final float[] F = {20, 25, 31.5f, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400, 500, 630, 800, 1000,
            1250, 1600, 2000, 2500, 3150, 4000, 5000, 6300, 8000, 10000, 12500, 16000, 20000};
    static final float[] CUT = new float[31];

    static {
        for (int i = 0; i < 30; i++) CUT[i] = (float) Math.sqrt(F[i] * F[i + 1]);
        CUT[30] = 21000f;
    }

    static final float[] gain = new float[31];
    static float pre = 0;
    static boolean on = true;
    static int mode = 0;
    static EqService inst;

    static class Fx {
        DynamicsProcessing d;
        float[] ag = new float[31];
        float ap = 999;
    }

    final Map<Integer, Fx> fx = new ConcurrentHashMap<>();
    final Map<Integer, String> pk = new ConcurrentHashMap<>();
    final Handler h = new Handler(Looper.getMainLooper());
    volatile String err = "";

    final BroadcastReceiver rc = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            int s = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1);
            if (s <= 0) return;
            if (AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION.equals(i.getAction())) {
                if (mode == 0) add(s, i.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME));
            } else {
                drop(s);
            }
        }
    };

    static void load(String s) {
        if (s == null || s.isEmpty()) return;
        try {
            String[] p = s.split("\\|");
            String[] g = p[3].split(",");
            on = p[0].equals("1");
            mode = Integer.parseInt(p[1]);
            pre = Float.parseFloat(p[2]);
            for (int i = 0; i < 31; i++) gain[i] = Float.parseFloat(g[i]);
        } catch (Exception e) {
        }
    }

    static void update() {
        EqService s = inst;
        if (s != null) s.h.post(s::refresh);
    }

    static String status() {
        EqService s = inst;
        if (s == null) return "Layanan belum jalan.";
        String r = s.pk.isEmpty()
                ? "Belum ada pemutar terdeteksi. Putar atau ulangi lagu di aplikasi musik."
                : "Aktif di: " + String.join(", ", s.pk.values());
        if (!s.err.isEmpty()) r += "\nError: " + s.err;
        return r;
    }

    void add(int s, String p) {
        String name = p == null ? "?" : p;
        if (fx.containsKey(s)) {
            pk.put(s, name);
            return;
        }
        try {
            DynamicsProcessing.Eq e = new DynamicsProcessing.Eq(true, true, 31);
            for (int i = 0; i < 31; i++) e.setBand(i, new DynamicsProcessing.EqBand(true, CUT[i], 0f));
            DynamicsProcessing.Config.Builder b = new DynamicsProcessing.Config.Builder(
                    DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION, 2, true, 31, false, 0, false, 0, false);
            b.setPreEqAllChannelsTo(e);
            Fx f = new Fx();
            f.d = new DynamicsProcessing(0, s, b.build());
            fx.put(s, f);
            pk.put(s, name);
            err = "";
            push(f);
        } catch (Throwable t) {
            pk.put(s, name + " (gagal)");
            err = String.valueOf(t.getMessage());
        }
    }

    void drop(int s) {
        Fx f = fx.remove(s);
        pk.remove(s);
        if (f != null) {
            try {
                f.d.release();
            } catch (Throwable t) {
            }
        }
    }

    void clear() {
        for (Fx f : fx.values()) {
            try {
                f.d.release();
            } catch (Throwable t) {
            }
        }
        fx.clear();
        pk.clear();
    }

    void push(Fx f) {
        try {
            f.d.setEnabled(on);
            if (f.ap != pre) {
                f.d.setInputGainAllChannelsTo(pre);
                f.ap = pre;
            }
            for (int i = 0; i < 31; i++) {
                if (f.ag[i] != gain[i]) {
                    f.d.setPreEqBandAllChannelsTo(i, new DynamicsProcessing.EqBand(true, CUT[i], gain[i]));
                    f.ag[i] = gain[i];
                }
            }
        } catch (Throwable t) {
            err = String.valueOf(t.getMessage());
        }
    }

    void refresh() {
        if (mode == 1) {
            if (!fx.containsKey(0)) {
                clear();
                add(0, "global");
            }
        } else if (fx.containsKey(0)) {
            clear();
        }
        for (Fx f : fx.values()) push(f);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        load(getSharedPreferences("eq", 0).getString("s", ""));
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("eq", "Equalizer", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "eq")
                .setContentTitle("Equalizer aktif")
                .setContentText("Ketuk untuk membuka")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE))
                .build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        IntentFilter f = new IntentFilter();
        f.addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION);
        f.addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rc, f, Context.RECEIVER_EXPORTED);
        else registerReceiver(rc, f);
        refresh();
    }

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try {
            unregisterReceiver(rc);
        } catch (Exception e) {
        }
        clear();
        inst = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }
}
